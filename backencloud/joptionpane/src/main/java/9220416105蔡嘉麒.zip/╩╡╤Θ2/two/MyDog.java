package 实验2.two;


public class MyDog {
    public static void main(String args[]) {
        Dog dog = new Dog("pyn", "red", 1);
        System.out.println(dog.toString());
    }
}
